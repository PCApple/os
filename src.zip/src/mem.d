mem.o: mem.c include/mem.h include/multiboot.h include/utils.h
