asm/lgdt.o: asm/lgdt.S
