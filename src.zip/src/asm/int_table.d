asm/int_table.o: asm/int_table.S
