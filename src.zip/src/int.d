int.o: int.c include/int.h include/print.h include/io.h \
 include/scheduler.h include/tcb.h include/heap.h include/utils.h \
 include/mem.h include/multiboot.h include/pic.h
