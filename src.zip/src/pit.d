pit.o: pit.c include/pit.h include/io.h include/int.h include/print.h \
 include/scheduler.h include/tcb.h include/heap.h include/utils.h \
 include/mem.h include/multiboot.h include/pic.h
