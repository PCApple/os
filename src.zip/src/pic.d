pic.o: pic.c include/pic.h include/io.h
