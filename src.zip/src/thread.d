thread.o: thread.c include/thread.h include/scheduler.h include/tcb.h \
 include/heap.h include/utils.h include/io.h include/mem.h \
 include/multiboot.h include/pic.h include/print.h
