init.o: init.c include/multiboot.h include/mem.h include/multiboot.h \
 include/utils.h include/print.h include/scheduler.h include/tcb.h \
 include/heap.h include/io.h include/mem.h include/pic.h include/print.h \
 include/thread.h include/scheduler.h include/gdt.h include/ide.h
