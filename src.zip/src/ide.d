ide.o: ide.c include/ide.h include/print.h include/io.h
